import requests
import inspect
from utils.firebase import upload_text_to_firebase

def init(project_name):
    url = 'http://localhost:8080/projects'
    response = requests.post(url, json={'project_name': project_name, 'api_key': '80f313d06b23a2bc7fb218e397068063'})

    if response.status_code == 201:
        print('Request was successful!')
        print('Response body: ', response.text)
    else:
        print('Request failed with status code: ', response.status_code)

# TODO: Modularize this
def trace(func):
    def wrapper(*args, **kwargs):
        print("args: ", args)
        print("kwargs: ", kwargs)
        source_code = inspect.getsource(func)

        # Save the source code to a file
        # TODO: Update this to sending a request to the service
        public_url = upload_text_to_firebase(source_code, 'code-snippet.txt')
        print("public_url: ", public_url)
        url = 'http://localhost:8080/runs'
        response = requests.post(url, json={'codeSnippetUrl': public_url, 'api_key': '80f313d06b23a2bc7fb218e397068063'})
        if response.status_code == 201:
            print('Request was successful!')
            print('Response body: ', response.text)
        else:
            print('Request failed with status code: ', response.status_code)
        # with open(func.__name__ + '.py', 'w') as file: 
        #     file.write(source_code)
        
        # call the original function
        return func(*args, **kwargs)
    return wrapper